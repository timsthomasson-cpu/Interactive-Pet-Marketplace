import { PageShell } from "@/components/layout";
import { CompareTable, GroupedProducts, HeroSection, MobileShopPills, ShopByNeed } from "@/components/sections";
import { products } from "@/components/site-data";
import Link from "next/link";
export default function HomePage() {
  return (
    <PageShell>
      <HeroSection />
      <MobileShopPills />
      <ShopByNeed />
      <section className="hidden md:block bg-white pt-2 pb-10 sm:pt-3 sm:pb-12">
        <div className="container-shell">
          <div className="grid gap-10 sm:grid-cols-2 sm:gap-16">
            <div className="flex flex-col items-center text-center">
              <Link href="/interactive-pets" className="inline-flex items-center justify-center rounded-full bg-trust-500 px-8 py-5 text-base font-semibold text-white transition hover:-translate-y-0.5 hover:bg-trust-600">Explore Plushy Companions</Link>
              <p className="mt-4 max-w-sm text-sm leading-7 text-slate-600">Soft, engaging companion pets with touch response, sounds, and comforting interaction.</p>
            </div>
            <div className="flex flex-col items-center text-center">
              <Link href="/ai-robotic-pets" className="inline-flex items-center justify-center rounded-full bg-trust-500 px-8 py-5 text-base font-semibold text-white transition hover:-translate-y-0.5 hover:bg-trust-600">Explore AI & Robotic Pets</Link>
              <p className="mt-4 max-w-sm text-sm leading-7 text-slate-600">Advanced smart pets with movement, sensors, app features and interactive behavior.</p>
            </div>
          </div>
        </div>
      </section>
      <div className="h-[3px] bg-gradient-to-r from-transparent via-brand-400 to-trust-400"></div>
      <GroupedProducts items={products} />
      <CompareTable items={products} title="All products at a glance" text="A quick scan of every smart pet on the site — type, audience, highlight, rating, and price." />
    </PageShell>
  );
}
