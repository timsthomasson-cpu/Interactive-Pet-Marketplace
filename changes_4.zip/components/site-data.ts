// AUTO-GENERATED FILE — DO NOT EDIT BY HAND.
// Run `npm run generate:products` to regenerate.
// Source: Documentation/Product Matrix.xlsx (single source of truth)
//
// Generated: 2026-05-11T17:04:52.785Z

export type ProductFlags = {
  gifts: boolean;
  topPick: boolean;
  camera: boolean;
  internetAccess: boolean;
  affiliateAgreement: boolean;
};

export type Product = {
  slug: string;
  name: string;
  manufacturer: string;
  manufacturerAndProduct: string;
  type: "Interactive" | "AI & Robotic" | string;
  category: string;
  bestFor: string[];
  blurb: string;
  features: string[];
  highlight: string;
  rating?: number;
  reviewCount?: number;
  ratingSource: string;
  ratingLastChecked: string;
  ratingUrl: string;
  price: string;
  priceSource: string;
  priceLastChecked: string;
  priceCategory: "Premium" | "Best Value" | "Budget Friendly" | string;
  productUrl: string;
  imageUrl?: string;
  flags: ProductFlags;
};

export const products: Product[] = [
  {
    "slug": "ebo-x-famiybot",
    "name": "EBO X FamiyBot",
    "manufacturer": "Enabot",
    "manufacturerAndProduct": "Enabot EBO X FamiyBot",
    "type": "AI & Robotic",
    "category": "Robot",
    "bestFor": [
      "Families",
      "Seniors"
    ],
    "blurb": "AI home monitoring robot and AI Assistant designed to keep your home, pets, and loved ones connected and secure. The robot pet camera lets you check in and visit anytime from your smartphone. Monitors home and family. Sends alerts when anomalies are detected.",
    "features": [
      "Fall Detection",
      "Intelligent Patrol",
      "Smart Personal Assistant"
    ],
    "highlight": "Intelligent companion, assistant, and monitor.",
    "rating": 4.5,
    "reviewCount": 8,
    "ratingSource": "Walmart",
    "ratingLastChecked": "2026-05-07",
    "ratingUrl": "Amazon.com : Enabot robot",
    "price": "$789.00",
    "priceSource": "Enabot Store",
    "priceLastChecked": "2026-05-07",
    "priceCategory": "Premium",
    "productUrl": "",
    "imageUrl": "/images/products/interactive_pet_toys.png",
    "flags": {
      "gifts": true,
      "topPick": false,
      "camera": false,
      "internetAccess": false,
      "affiliateAgreement": false
    }
  },
  {
    "slug": "ebo-max-famiybot",
    "name": "EBO Max FamiyBot",
    "manufacturer": "Enabot",
    "manufacturerAndProduct": "Enabot EBO Max FamiyBot",
    "type": "AI & Robotic",
    "category": "Robot",
    "bestFor": [
      "Seniors",
      "Families"
    ],
    "blurb": "AI home monitoring robot and AI Assistant designed to keep your home, pets, and loved ones connected and secure. The robot pet camera lets you check in and visit anytime from your smartphone. Monitors home and family. Sends alerts when anomalies are detected.",
    "features": [
      "Fall Detection",
      "Intelligent Patrol",
      "Multimodal AI"
    ],
    "highlight": "Intelligent companion, assistant, and home monitor.",
    "rating": 0,
    "reviewCount": 0,
    "ratingSource": "Enabot Store",
    "ratingLastChecked": "2026-05-07",
    "ratingUrl": "FamiyBot – Enabot Store",
    "price": "$549.00",
    "priceSource": "Enabot Store",
    "priceLastChecked": "2026-05-07",
    "priceCategory": "Premium",
    "productUrl": "",
    "imageUrl": "/images/products/interactive_pet_toys.png",
    "flags": {
      "gifts": true,
      "topPick": false,
      "camera": false,
      "internetAccess": false,
      "affiliateAgreement": false
    }
  },
  {
    "slug": "ebo-air-2-plus-famiybot",
    "name": "EBO Air 2 Plus FamiyBot",
    "manufacturer": "Enabot",
    "manufacturerAndProduct": "Enabot EBO Air 2 Plus FamiyBot",
    "type": "AI & Robotic",
    "category": "Robot",
    "bestFor": [
      "Families",
      "Children"
    ],
    "blurb": "AI home monitoring robot and AI Assistant designed to keep your home, pets, and loved ones connected and secure. The robot pet camera lets you check in and visit anytime from your smartphone. Monitors home and family. Sends alerts when anomalies are detected.",
    "features": [
      "AI Assistant",
      "Smart Patrol",
      "Multiple Colors"
    ],
    "highlight": "Intelligent companion, assistant, and home monitor.",
    "rating": 4.1,
    "reviewCount": 98,
    "ratingSource": "Amazon",
    "ratingLastChecked": "2026-05-07",
    "ratingUrl": "Amazon.com : Enabot robot",
    "price": "$359.00",
    "priceSource": "Enabot Store",
    "priceLastChecked": "2026-05-08",
    "priceCategory": "Premium",
    "productUrl": "",
    "imageUrl": "/images/products/interactive_pet_toys.png",
    "flags": {
      "gifts": true,
      "topPick": true,
      "camera": false,
      "internetAccess": false,
      "affiliateAgreement": false
    }
  },
  {
    "slug": "ebo-air-2s-famiybot",
    "name": "EBO Air 2S FamiyBot",
    "manufacturer": "Enabot",
    "manufacturerAndProduct": "Enabot EBO Air 2S FamiyBot",
    "type": "AI & Robotic",
    "category": "Robot",
    "bestFor": [
      "Families",
      "Children"
    ],
    "blurb": "AI home monitoring robot and AI Assistant designed to keep your home, pets, and loved ones connected and secure. The robot pet camera lets you check in and visit anytime from your smartphone. Monitors home and family. Sends alerts when anomalies are detected.",
    "features": [
      "AI Tracking",
      "Dual Screen Eyes",
      "Budget Friendly"
    ],
    "highlight": "Intelligent companion, assistant, and home monitor.",
    "rating": 4.1,
    "reviewCount": 38,
    "ratingSource": "Amazon",
    "ratingLastChecked": "2026-05-07",
    "ratingUrl": "Amazon.com : Enabot robot",
    "price": "$279.00",
    "priceSource": "Enabot Store",
    "priceLastChecked": "2026-05-09",
    "priceCategory": "Premium",
    "productUrl": "",
    "imageUrl": "/images/products/interactive_pet_toys.png",
    "flags": {
      "gifts": true,
      "topPick": false,
      "camera": false,
      "internetAccess": false,
      "affiliateAgreement": false
    }
  },
  {
    "slug": "ebo-air-2-famiybot",
    "name": "EBO Air 2 FamiyBot",
    "manufacturer": "Enabot",
    "manufacturerAndProduct": "Enabot EBO Air 2 FamiyBot",
    "type": "AI & Robotic",
    "category": "Robot",
    "bestFor": [
      "Families",
      "Children"
    ],
    "blurb": "AI home monitoring robot and AI Assistant designed to keep your home, pets, and loved ones connected and secure. The robot pet camera lets you check in and visit anytime from your smartphone. Monitors home and family. Sends alerts when anomalies are detected.",
    "features": [
      "Intelligent Patrol",
      "Budget Friendly",
      "Laser Pointer"
    ],
    "highlight": "Intelligent companion, assistant, and home monitor.",
    "rating": 4,
    "reviewCount": 300,
    "ratingSource": "Amazon",
    "ratingLastChecked": "2026-05-07",
    "ratingUrl": "Amazon.com : Enabot robot",
    "price": "$179.00",
    "priceSource": "Enabot Store",
    "priceLastChecked": "2026-05-10",
    "priceCategory": "Best Value",
    "productUrl": "",
    "imageUrl": "/images/products/interactive_pet_toys.png",
    "flags": {
      "gifts": true,
      "topPick": true,
      "camera": false,
      "internetAccess": false,
      "affiliateAgreement": false
    }
  },
  {
    "slug": "rola-mini-pet-monitor",
    "name": "ROLA Mini Pet Monitor",
    "manufacturer": "Enabot",
    "manufacturerAndProduct": "Enabot ROLA Mini Pet Monitor",
    "type": "AI & Robotic",
    "category": "Robot",
    "bestFor": [
      "Pets",
      "Families"
    ],
    "blurb": "AI home monitoring robot designed to keep your pets entertained, connected, and secure. Check in and interact with your pet anytime from your smartphone.",
    "features": [
      "Night Vision",
      "Pet Entertainment Features",
      "25 Day Battery"
    ],
    "highlight": "Pet Companion and Monitor",
    "rating": 4.8,
    "reviewCount": 30,
    "ratingSource": "Enabot Store",
    "ratingLastChecked": "2026-05-07",
    "ratingUrl": "ROLA Mini FamiyBot – 2K Movable Camera & Monitor – Enabot Store",
    "price": "$139.00",
    "priceSource": "Enabot Store",
    "priceLastChecked": "2026-05-11",
    "priceCategory": "Best Value",
    "productUrl": "",
    "imageUrl": "/images/products/interactive_pet_toys.png",
    "flags": {
      "gifts": true,
      "topPick": false,
      "camera": false,
      "internetAccess": false,
      "affiliateAgreement": false
    }
  },
  {
    "slug": "companion-pet-pup-golden",
    "name": "Companion Pet Pup Golden",
    "manufacturer": "Joy for All",
    "manufacturerAndProduct": "Joy for All Companion Pet Pup Golden",
    "type": "Interactive",
    "category": "Dog",
    "bestFor": [
      "Seniors",
      "Children"
    ],
    "blurb": "Lifelike animatronic Golden Retriever puppy with BarkBack voice response, calming heartbeat, and soft hypoallergenic fur. Created with caregivers to comfort seniors with Alzheimer’s and dementia",
    "features": [
      "BarkBack voice response",
      "Heartbeat sensation",
      "Soft golden fur"
    ],
    "highlight": "Interactive senior companion",
    "rating": 4.5,
    "reviewCount": 5163,
    "ratingSource": "Amazon",
    "ratingLastChecked": "2026-05-08",
    "ratingUrl": "Amazon.com: JOY FOR ALL Ageless Innovation Companion Pet for Seniors - Lifelike Animatronic Dog - Realistic Soft-Touch Coat & Heartbeat - Therapy Stuffed Animal - Toy for Alzheimer's & Dementia - Golden Pup : Hasbro: Everything Else",
    "price": "$179.00",
    "priceSource": "Amazon",
    "priceLastChecked": "2026-05-08",
    "priceCategory": "Best Value",
    "productUrl": "",
    "imageUrl": "/images/products/Mr-Dog.png",
    "flags": {
      "gifts": true,
      "topPick": true,
      "camera": false,
      "internetAccess": false,
      "affiliateAgreement": false
    }
  },
  {
    "slug": "companion-pet-pup-freckled",
    "name": "Companion Pet Pup Freckled",
    "manufacturer": "Joy for All",
    "manufacturerAndProduct": "Joy for All Companion Pet Pup Freckled",
    "type": "Interactive",
    "category": "Dog",
    "bestFor": [
      "Seniors",
      "Children"
    ],
    "blurb": "Lifelike animatronic puppy with brown-and-white freckled fur, floppy ears, BarkBack voice response, and calming heartbeat. The newest Joy for All companion pet for seniors.",
    "features": [
      "BarkBack voice response",
      "Heartbeat sensation",
      "Freckled brown coat"
    ],
    "highlight": "Barking, Cuddling, tail wagging companion.",
    "rating": 4.5,
    "reviewCount": 5163,
    "ratingSource": "Amazon",
    "ratingLastChecked": "2026-05-08",
    "ratingUrl": "Amazon.com: JOY FOR ALL Ageless Innovation Companion Pet for Seniors - Lifelike Animatronic Dog - Realistic Soft-Touch Coat & Heartbeat - Therapy Stuffed Animal - Toy for Alzheimer's & Dementia - Golden Pup : Hasbro: Everything Else",
    "price": "$179.00",
    "priceSource": "Amazon",
    "priceLastChecked": "2026-05-08",
    "priceCategory": "Best Value",
    "productUrl": "",
    "imageUrl": "/images/products/Mr-Dog.png",
    "flags": {
      "gifts": true,
      "topPick": false,
      "camera": false,
      "internetAccess": false,
      "affiliateAgreement": false
    }
  },
  {
    "slug": "companion-pet-cat-silver",
    "name": "Companion Pet Cat Silver",
    "manufacturer": "Joy for All",
    "manufacturerAndProduct": "Joy for All Companion Pet Cat Silver",
    "type": "Interactive",
    "category": "Cat",
    "bestFor": [
      "Seniors",
      "Children"
    ],
    "blurb": "Animatronic silver-and-white cat that purrs, meows, and rolls over for tummy rubs. Helps reduce loneliness and dementia-related agitation with soothing VibraPurr technology.",
    "features": [
      "VibraPurr technology",
      "Motion sensors",
      "Silver/white fur"
    ],
    "highlight": "Fluffy, soft, and interactive companion",
    "rating": 4.5,
    "reviewCount": 11640,
    "ratingSource": "Amazon",
    "ratingLastChecked": "2026-05-08",
    "ratingUrl": "Amazon.com: JOY FOR ALL Ageless Innovation Companion Pet for Seniors - Lifelike Animatronic Dog - Realistic Soft-Touch Coat & Heartbeat - Therapy Stuffed Animal - Toy for Alzheimer's & Dementia - Golden Pup : Hasbro: Everything Else",
    "price": "$159.99",
    "priceSource": "Amazon",
    "priceLastChecked": "2026-05-08",
    "priceCategory": "Best Value",
    "productUrl": "",
    "imageUrl": "/images/products/Joy-for-All-Companion-Cat-Silver.png",
    "flags": {
      "gifts": true,
      "topPick": false,
      "camera": false,
      "internetAccess": false,
      "affiliateAgreement": false
    }
  },
  {
    "slug": "companion-pet-cat-orange-tabby",
    "name": "Companion Pet Cat Orange Tabby",
    "manufacturer": "Joy for All",
    "manufacturerAndProduct": "Joy for All Companion Pet Cat Orange Tabby",
    "type": "Interactive",
    "category": "Cat",
    "bestFor": [
      "Seniors",
      "Children"
    ],
    "blurb": "Animatronic orange tabby cat with realistic purring, soft fur, and lifelike movements. Meows, grooms, and rolls over to touch. Award-winning companion pet for seniors.",
    "features": [
      "VibraPurr technology",
      "Motion sensors",
      "Orange tabby fur"
    ],
    "highlight": "Perfect gift for kids and older adults.",
    "rating": 4.5,
    "reviewCount": 11640,
    "ratingSource": "Amazon",
    "ratingLastChecked": "2026-05-08",
    "ratingUrl": "Amazon.com: JOY FOR ALL Ageless Innovation Companion Pet for Seniors - Lifelike Animatronic Dog - Realistic Soft-Touch Coat & Heartbeat - Therapy Stuffed Animal - Toy for Alzheimer's & Dementia - Golden Pup : Hasbro: Everything Else",
    "price": "$159.99",
    "priceSource": "Amazon",
    "priceLastChecked": "2026-05-08",
    "priceCategory": "Best Value",
    "productUrl": "",
    "imageUrl": "/images/products/Joy-for-All-Companion-Cat-Orange-Tabby.png",
    "flags": {
      "gifts": true,
      "topPick": false,
      "camera": false,
      "internetAccess": false,
      "affiliateAgreement": false
    }
  },
  {
    "slug": "companion-pet-cat-tuxedo",
    "name": "Companion Pet Cat Tuxedo",
    "manufacturer": "Joy for All",
    "manufacturerAndProduct": "Joy for All Companion Pet Cat Tuxedo",
    "type": "Interactive",
    "category": "Cat",
    "bestFor": [
      "Seniors",
      "Children"
    ],
    "blurb": "Animatronic black-and-white tuxedo cat with realistic purring, motion-responsive interactions, and soft hypoallergenic fur. A calming, low-maintenance companion for any age.",
    "features": [
      "VibraPurr technology",
      "Motion sensors",
      "Black/white tuxedo fur"
    ],
    "highlight": "Improve quality-of-life and overall well-being",
    "rating": 4.5,
    "reviewCount": 11640,
    "ratingSource": "Amazon",
    "ratingLastChecked": "2026-05-08",
    "ratingUrl": "Amazon.com: JOY FOR ALL Ageless Innovation Companion Pet for Seniors - Lifelike Animatronic Dog - Realistic Soft-Touch Coat & Heartbeat - Therapy Stuffed Animal - Toy for Alzheimer's & Dementia - Golden Pup : Hasbro: Everything Else",
    "price": "$159.99",
    "priceSource": "Amazon",
    "priceLastChecked": "2026-05-08",
    "priceCategory": "Best Value",
    "productUrl": "",
    "imageUrl": "/images/products/Joy-for-All-Companion-Cat-Tuxedo.jpg",
    "flags": {
      "gifts": true,
      "topPick": true,
      "camera": false,
      "internetAccess": false,
      "affiliateAgreement": false
    }
  },
  {
    "slug": "matecat-pro",
    "name": "MateCat Pro",
    "manufacturer": "Chongker",
    "manufacturerAndProduct": "Chongker MateCat Pro",
    "type": "Interactive",
    "category": "Cat",
    "bestFor": [
      "Seniors",
      "Children"
    ],
    "blurb": "Hyper-realistic robotic cat with voice wake-up, blinking, purring, and tail movement. Provides emotional support, companionship, and anxiety relief. Handcrafted fur for a premium feel.",
    "features": [
      "Realistic purr & heartbeat",
      "Blinking & ear movement",
      "Handcrafted fur"
    ],
    "highlight": "Affordable and incredibly lifelike",
    "rating": 5,
    "reviewCount": 16,
    "ratingSource": "Chongker Website",
    "ratingLastChecked": "2026-05-08",
    "ratingUrl": "Interactive Stuffed Animals & Robot Cats for Emotional Support – Chongker",
    "price": "$178.00",
    "priceSource": "Chongker Website",
    "priceLastChecked": "2026-05-08",
    "priceCategory": "Best Value",
    "productUrl": "",
    "imageUrl": "/images/products/Sweetie-Cat.png",
    "flags": {
      "gifts": true,
      "topPick": true,
      "camera": false,
      "internetAccess": false,
      "affiliateAgreement": false
    }
  },
  {
    "slug": "matecat-1-1",
    "name": "MateCat 1.1",
    "manufacturer": "Chongker",
    "manufacturerAndProduct": "Chongker MateCat 1.1",
    "type": "Interactive",
    "category": "Cat",
    "bestFor": [
      "Seniors",
      "Children"
    ],
    "blurb": "Companion robot cat designed for sensory comfort. Touch-responsive sensors trigger purrs, meows, and gentle movements. Studied through 200+ hours of real cat behavior simulation. Heartbeat feature provides a calming, realistic experience.",
    "features": [
      "Touch-sensitive zones",
      "Realistic heartbeat",
      "Sensory comfort design"
    ],
    "highlight": "Calming, anxiety reducing actions and feel.",
    "rating": 4,
    "reviewCount": 2,
    "ratingSource": "Chongker Website",
    "ratingLastChecked": "2026-05-08",
    "ratingUrl": "Interactive Stuffed Animals & Robot Cats for Emotional Support – Chongker",
    "price": "$149.00",
    "priceSource": "Chongker Website",
    "priceLastChecked": "2026-05-08",
    "priceCategory": "Best Value",
    "productUrl": "",
    "imageUrl": "/images/products/Chongker-Percy-Robot-Cat.jpg",
    "flags": {
      "gifts": true,
      "topPick": false,
      "camera": false,
      "internetAccess": false,
      "affiliateAgreement": false
    }
  },
  {
    "slug": "percy-1-1-robotic-dog",
    "name": "Percy 1.1 Robotic Dog",
    "manufacturer": "Chongker",
    "manufacturerAndProduct": "Chongker Percy 1.1 Robotic Dog",
    "type": "Interactive",
    "category": "Dog",
    "bestFor": [
      "Seniors",
      "Children"
    ],
    "blurb": "Handmade realistic robotic dog with weighted body for sensory comfort, touch sensors, and a calming heartbeat simulation. Crafted through 30+ steps for exceptional detail. Charges via USB-C with 8+ hours of battery.",
    "features": [
      "Weighted comfort design",
      "Touch & heartbeat sensors",
      "USB-C rechargeable"
    ],
    "highlight": "Most affordable interactive dog",
    "rating": 5,
    "reviewCount": 4,
    "ratingSource": "Chongker Website",
    "ratingLastChecked": "2026-05-08",
    "ratingUrl": "Interactive Stuffed Animals & Robot Cats for Emotional Support – Chongker",
    "price": "$89.00",
    "priceSource": "Chongker Website",
    "priceLastChecked": "2026-05-08",
    "priceCategory": "Budget Friendly",
    "productUrl": "",
    "imageUrl": "/images/products/Mr-Dog.png",
    "flags": {
      "gifts": true,
      "topPick": true,
      "camera": false,
      "internetAccess": false,
      "affiliateAgreement": false
    }
  },
  {
    "slug": "percy-robot-cat",
    "name": "Percy Robot Cat",
    "manufacturer": "Chongker",
    "manufacturerAndProduct": "Chongker Percy Robot Cat",
    "type": "Interactive",
    "category": "Cat",
    "bestFor": [
      "Seniors",
      "Children"
    ],
    "blurb": "Affordable handmade robotic cat with five touch-sensitive zones, purring, meowing, and a realistic heartbeat. Weighted plush body designed for emotional support and stress relief.",
    "features": [
      "5 touch zones",
      "Heartbeat & purring",
      "Weighted plush body"
    ],
    "highlight": "Most affordable robot cat",
    "rating": 5,
    "reviewCount": 16,
    "ratingSource": "Chongker Website",
    "ratingLastChecked": "2026-05-08",
    "ratingUrl": "Interactive Stuffed Animals & Robot Cats for Emotional Support – Chongker",
    "price": "$89.00",
    "priceSource": "Chongker Website",
    "priceLastChecked": "2026-05-08",
    "priceCategory": "Budget Friendly",
    "productUrl": "",
    "imageUrl": "/images/products/Chongker-Percy-Robot-Cat.jpg",
    "flags": {
      "gifts": true,
      "topPick": true,
      "camera": false,
      "internetAccess": false,
      "affiliateAgreement": false
    }
  },
  {
    "slug": "breathing-red-panda-plush",
    "name": "Breathing Red Panda Plush",
    "manufacturer": "Chongker",
    "manufacturerAndProduct": "Chongker Breathing Red Panda Plush",
    "type": "Interactive",
    "category": "Panda",
    "bestFor": [
      "Seniors",
      "Children"
    ],
    "blurb": "Lifelike red panda plush with realistic breathing simulation. A weighted, calming companion designed for stress relief, anxiety support, and quiet comfort. Hand-crafted for exceptional detail.",
    "features": [
      "Realistic breathing motion",
      "Weighted plush body",
      "Calming companion"
    ],
    "highlight": "Unique anxiety relief",
    "rating": 5,
    "reviewCount": 2,
    "ratingSource": "Chongker Website",
    "ratingLastChecked": "2026-05-08",
    "ratingUrl": "Interactive Stuffed Animals & Robot Cats for Emotional Support – Chongker",
    "price": "$119.00",
    "priceSource": "Chongker Website",
    "priceLastChecked": "2026-05-08",
    "priceCategory": "Best Value",
    "productUrl": "",
    "imageUrl": "/images/products/red_panda.png",
    "flags": {
      "gifts": true,
      "topPick": false,
      "camera": false,
      "internetAccess": false,
      "affiliateAgreement": false
    }
  },
  {
    "slug": "wuffy-robot-puppy",
    "name": "Wuffy Robot Puppy",
    "manufacturer": "Wuffy",
    "manufacturerAndProduct": "Wuffy Wuffy Robot Puppy",
    "type": "Interactive",
    "category": "Dog",
    "bestFor": [
      "Children",
      "Families"
    ],
    "blurb": "Affordable interactive robot puppy featuring touch sensors, walking, barking, and tail wagging. Runs on AA batteries with no app or Wi-Fi setup needed — instant out-of-box play. A kid-friendly starter pet alternative.",
    "features": [
      "Touch sensor responses",
      "Walks, barks, wags",
      "AA batteries — no app"
    ],
    "highlight": "Best price for interactive pet",
    "rating": 3,
    "reviewCount": 80,
    "ratingSource": "Amazon",
    "ratingLastChecked": "2026-05-09",
    "ratingUrl": "Amazon.com: chinatera 2026 Wuffy Robot Dog Lifelike Toy Dog, Interactive Robot with Touch Sensing Voice Mimic Licking Motion Leash Remote Soft Fur for Kids Battery Powered (Style-G) : Toys & Games",
    "price": "$25.99",
    "priceSource": "Amazon",
    "priceLastChecked": "2026-05-09",
    "priceCategory": "Budget Friendly",
    "productUrl": "",
    "imageUrl": "Amazon.com: chinatera 2026 Wuffy Robot Dog Lifelike Toy Dog, Interactive Robot with Touch Sensing Voice Mimic Licking Motion Leash Remote Soft Fur for Kids Battery Powered (Style-G) : Toys & Games",
    "flags": {
      "gifts": true,
      "topPick": false,
      "camera": false,
      "internetAccess": false,
      "affiliateAgreement": false
    }
  },
  {
    "slug": "kamomo",
    "name": "KAMOMO",
    "manufacturer": "Ropet",
    "manufacturerAndProduct": "Ropet KAMOMO",
    "type": "Interactive",
    "category": "Robot",
    "bestFor": [
      "children",
      "Families"
    ],
    "blurb": "Ropet KAMOMO AI Robot Pet is an interactive AI robot pet with lifelike emotions, touch response, and voice interaction. Designed for companionship, stress relief, and family fun, it reacts to attention and creates engaging daily interactions.",
    "features": [
      "Touch & motion response",
      "Enhances nurturing skills",
      "Builds personal connections"
    ],
    "highlight": "Ultimate AI Interactions",
    "rating": 4.3,
    "reviewCount": 17,
    "ratingSource": "Amazon",
    "ratingLastChecked": "2026-05-10",
    "ratingUrl": "Amazon.com: Ropet KAMOMO Companion Interactive Robot Pet, Emotional Support for Kids and Adults, AI Desk Robots, Anxiety Relief Comfort Gift : Toys & Games",
    "price": "$329.00",
    "priceSource": "Amazon",
    "priceLastChecked": "2026-05-10",
    "priceCategory": "Premium",
    "productUrl": "",
    "imageUrl": "/images/products/interactive_pet_toys.png",
    "flags": {
      "gifts": true,
      "topPick": true,
      "camera": true,
      "internetAccess": true,
      "affiliateAgreement": false
    }
  },
  {
    "slug": "original-border-collie",
    "name": "Original Border Collie",
    "manufacturer": "Perfect Petzzz",
    "manufacturerAndProduct": "Perfect Petzzz Original Border Collie",
    "type": "Interactive",
    "category": "Dog",
    "bestFor": [
      "Children",
      "Seniors"
    ],
    "blurb": "Perfect Petzzz Border Collie is a lifelike breathing plush dog with soft fur, realistic sleeping motions, and calming companionship. Ideal for seniors, children, and pet lovers seeking comfort without the care of a live pet.",
    "features": [
      "Breathes",
      "Soft and cuddly",
      "Very affordable"
    ],
    "highlight": "Affordable  breathing, super cuddly dog.",
    "rating": 4.3,
    "reviewCount": 403,
    "ratingSource": "Amazon",
    "ratingLastChecked": "2026-05-08",
    "ratingUrl": "Amazon.com : perfect Petzzz cat",
    "price": "$44.45",
    "priceSource": "Amazon",
    "priceLastChecked": "2026-05-08",
    "priceCategory": "Budget Friendly",
    "productUrl": "",
    "imageUrl": "/images/products/Mr-Border-Collie.png",
    "flags": {
      "gifts": true,
      "topPick": false,
      "camera": false,
      "internetAccess": false,
      "affiliateAgreement": false
    }
  },
  {
    "slug": "original-chocolate-lab",
    "name": "Original Chocolate Lab",
    "manufacturer": "Perfect Petzzz",
    "manufacturerAndProduct": "Perfect Petzzz Original Chocolate Lab",
    "type": "Interactive",
    "category": "Dog",
    "bestFor": [
      "Children",
      "Seniors"
    ],
    "blurb": "Perfect Petzzz Original Chocolate Lab is a lifelike breathing plush dog with soft fur, realistic sleeping motions, and calming companionship. Ideal for seniors, children, and pet lovers seeking comfort without the care of a live pet.",
    "features": [
      "Very affordable",
      "Breathes",
      "Soft and cuddly"
    ],
    "highlight": "Affordable  breathing, super cuddly dog.",
    "rating": 4.3,
    "reviewCount": 553,
    "ratingSource": "Amazon",
    "ratingLastChecked": "2026-05-08",
    "ratingUrl": "Amazon.com : perfect Petzzz cat",
    "price": "$44.45",
    "priceSource": "Amazon",
    "priceLastChecked": "2026-05-08",
    "priceCategory": "Budget Friendly",
    "productUrl": "",
    "imageUrl": "/images/products/Mr-Chocolate-Lab.png",
    "flags": {
      "gifts": true,
      "topPick": false,
      "camera": false,
      "internetAccess": false,
      "affiliateAgreement": false
    }
  },
  {
    "slug": "original-shih-tzu",
    "name": "Original Shih Tzu",
    "manufacturer": "Perfect Petzzz",
    "manufacturerAndProduct": "Perfect Petzzz Original Shih Tzu",
    "type": "Interactive",
    "category": "Dog",
    "bestFor": [
      "Children",
      "Seniors"
    ],
    "blurb": "Perfect Petzzz Shih Tzu is a lifelike breathing plush dog with soft fur, realistic sleeping motions, and calming companionship. Ideal for seniors, children, and pet lovers seeking comfort without the care of a live pet.",
    "features": [
      "Soft and cuddly",
      "Very affordable",
      "Breathes"
    ],
    "highlight": "Affordable  breathing, super cuddly dog.",
    "rating": 4.2,
    "reviewCount": 878,
    "ratingSource": "Amazon",
    "ratingLastChecked": "2026-05-08",
    "ratingUrl": "Amazon.com : perfect Petzzz cat",
    "price": "$44.45",
    "priceSource": "Amazon",
    "priceLastChecked": "2026-05-08",
    "priceCategory": "Budget Friendly",
    "productUrl": "",
    "imageUrl": "/images/products/Mr-Shih-Tzu.png",
    "flags": {
      "gifts": true,
      "topPick": true,
      "camera": false,
      "internetAccess": false,
      "affiliateAgreement": false
    }
  },
  {
    "slug": "original-beagle",
    "name": "Original Beagle",
    "manufacturer": "Perfect Petzzz",
    "manufacturerAndProduct": "Perfect Petzzz Original Beagle",
    "type": "Interactive",
    "category": "Dog",
    "bestFor": [
      "Children",
      "Seniors"
    ],
    "blurb": "Perfect Petzzz Original Beagle is a lifelike breathing plush dog with soft fur, realistic sleeping motions, and calming companionship. Ideal for seniors, children, and pet lovers seeking comfort without the care of a live pet.",
    "features": [
      "Breathes",
      "Soft and cuddly",
      "Very affordable"
    ],
    "highlight": "Affordable  breathing, super cuddly dog.",
    "rating": 4.4,
    "reviewCount": 466,
    "ratingSource": "Amazon",
    "ratingLastChecked": "2026-05-08",
    "ratingUrl": "Amazon.com : perfect Petzzz cat",
    "price": "$44.45",
    "priceSource": "Amazon",
    "priceLastChecked": "2026-05-08",
    "priceCategory": "Budget Friendly",
    "productUrl": "",
    "imageUrl": "/images/products/Mr-Beagle.png",
    "flags": {
      "gifts": true,
      "topPick": false,
      "camera": false,
      "internetAccess": false,
      "affiliateAgreement": false
    }
  },
  {
    "slug": "original-calico-cat",
    "name": "Original Calico Cat",
    "manufacturer": "Perfect Petzzz",
    "manufacturerAndProduct": "Perfect Petzzz Original Calico Cat",
    "type": "Interactive",
    "category": "Cat",
    "bestFor": [
      "Children",
      "Seniors"
    ],
    "blurb": "Perfect Petzzz Original Calico Cat is a lifelike breathing plush cat with soft fur and realistic sleeping motions. Provides calming companionship for seniors, children, and cat lovers without the care and upkeep of a live pet.",
    "features": [
      "Very affordable",
      "Breathes",
      "Soft and cuddly"
    ],
    "highlight": "Affordable  breathing, super cuddly cat.",
    "rating": 4.3,
    "reviewCount": 848,
    "ratingSource": "Amazon",
    "ratingLastChecked": "2026-05-08",
    "ratingUrl": "Amazon.com : perfect Petzzz cat",
    "price": "$44.45",
    "priceSource": "Amazon",
    "priceLastChecked": "2026-05-08",
    "priceCategory": "Budget Friendly",
    "productUrl": "",
    "imageUrl": "/images/products/Sweetie-Calico-Cat.png",
    "flags": {
      "gifts": true,
      "topPick": false,
      "camera": false,
      "internetAccess": false,
      "affiliateAgreement": false
    }
  },
  {
    "slug": "original-plush-white-cat",
    "name": "Original Plush White Cat",
    "manufacturer": "Perfect Petzzz",
    "manufacturerAndProduct": "Perfect Petzzz Original Plush White Cat",
    "type": "Interactive",
    "category": "Cat",
    "bestFor": [
      "Children",
      "Seniors"
    ],
    "blurb": "Perfect Petzzz Original Plush White Cat is a lifelike breathing plush cat with soft fur and realistic sleeping motions. Provides calming companionship for seniors, children, and cat lovers without the care and upkeep of a live pet.",
    "features": [
      "Soft and cuddly",
      "Very affordable",
      "Breathes"
    ],
    "highlight": "Affordable  breathing, super cuddly cat.",
    "rating": 4,
    "reviewCount": 54,
    "ratingSource": "Amazon",
    "ratingLastChecked": "2026-05-08",
    "ratingUrl": "Amazon.com : perfect Petzzz cat",
    "price": "$53.90",
    "priceSource": "Amazon",
    "priceLastChecked": "2026-05-08",
    "priceCategory": "Budget Friendly",
    "productUrl": "",
    "imageUrl": "/images/products/Sweetie-White-Cat.png",
    "flags": {
      "gifts": true,
      "topPick": false,
      "camera": false,
      "internetAccess": false,
      "affiliateAgreement": false
    }
  },
  {
    "slug": "original-black-and-white-shorthair-cat",
    "name": "Original Black and White Shorthair Cat",
    "manufacturer": "Perfect Petzzz",
    "manufacturerAndProduct": "Perfect Petzzz Original Black and White Shorthair Cat",
    "type": "Interactive",
    "category": "Cat",
    "bestFor": [
      "Children",
      "Seniors"
    ],
    "blurb": "Perfect Petzzz Original Black and White Shorthair Cat is a lifelike breathing plush cat with soft fur and realistic sleeping motions. Provides calming companionship for seniors, children, and cat lovers without the care and upkeep of a live pet.",
    "features": [
      "Very affordable",
      "Breathes",
      "Soft and cuddly"
    ],
    "highlight": "Affordable  breathing, super cuddly cat.",
    "rating": 4.4,
    "reviewCount": 1200,
    "ratingSource": "Amazon",
    "ratingLastChecked": "2026-05-08",
    "ratingUrl": "Amazon.com : perfect Petzzz cat",
    "price": "$44.45",
    "priceSource": "Amazon",
    "priceLastChecked": "2026-05-08",
    "priceCategory": "Budget Friendly",
    "productUrl": "",
    "imageUrl": "/images/products/Sweetie-Calico-Cat.png",
    "flags": {
      "gifts": true,
      "topPick": true,
      "camera": false,
      "internetAccess": false,
      "affiliateAgreement": false
    }
  },
  {
    "slug": "original-siamese-cat",
    "name": "Original Siamese Cat",
    "manufacturer": "Perfect Petzzz",
    "manufacturerAndProduct": "Perfect Petzzz Original Siamese Cat",
    "type": "Interactive",
    "category": "Cat",
    "bestFor": [
      "Children",
      "Seniors"
    ],
    "blurb": "Perfect Petzzz Siamese Cat is a lifelike breathing plush cat with soft fur and realistic sleeping motions. Provides calming companionship for seniors, children, and cat lovers without the care and upkeep of a live pet.",
    "features": [
      "Soft and cuddly",
      "Very affordable",
      "Breathes"
    ],
    "highlight": "Affordable  breathing, super cuddly cat.",
    "rating": 4.1,
    "reviewCount": 16,
    "ratingSource": "Amazon",
    "ratingLastChecked": "2026-05-08",
    "ratingUrl": "Amazon.com : perfect Petzzz cat",
    "price": "$53.90",
    "priceSource": "Amazon",
    "priceLastChecked": "2026-05-08",
    "priceCategory": "Budget Friendly",
    "productUrl": "",
    "imageUrl": "/images/products/Sweetie-Siamese-Cat.png",
    "flags": {
      "gifts": true,
      "topPick": false,
      "camera": false,
      "internetAccess": false,
      "affiliateAgreement": false
    }
  },
  {
    "slug": "18011-smart-robot-dog",
    "name": "18011 Smart Robot Dog",
    "manufacturer": "Ruko",
    "manufacturerAndProduct": "Ruko 18011 Smart Robot Dog",
    "type": "AI & Robotic",
    "category": "Dog",
    "bestFor": [
      "Children",
      "Families"
    ],
    "blurb": "Ruko 18011 Smart Robot Dog is an interactive robot puppy with touch response, LED facial expressions, gesture control, and programmable actions. Designed for kids, it encourages creativity, STEM learning, and engaging screen-free play.",
    "features": [
      "Spins, slides and dances",
      "Programmable",
      "30+ Interactive faces"
    ],
    "highlight": "Fun, affordable,  programmable robot puppy",
    "rating": 4.4,
    "reviewCount": 283,
    "ratingSource": "Amazon",
    "ratingLastChecked": "2026-05-08",
    "ratingUrl": "Amazon.com: Ruko 18011 Smart Robot Dog, Interactive Puppy with 30 LED Expressions, Programmable Play, 2.4 GHz Remote & Gesture Control, Toy for Kids Age 3+ : Toys & Games",
    "price": "$69.99",
    "priceSource": "Amazon",
    "priceLastChecked": "2026-05-08",
    "priceCategory": "Budget Friendly",
    "productUrl": "",
    "imageUrl": "/images/products/futuristic_ai_pets.png",
    "flags": {
      "gifts": true,
      "topPick": true,
      "camera": false,
      "internetAccess": false,
      "affiliateAgreement": false
    }
  },
  {
    "slug": "dj-furby",
    "name": "DJ Furby",
    "manufacturer": "Furby",
    "manufacturerAndProduct": "Furby DJ Furby",
    "type": "AI & Robotic",
    "category": "Robot",
    "bestFor": [
      "Children",
      "Families"
    ],
    "blurb": "DJ Furby Interactive Plush is an interactive electronic pet with voice activation, music, lights, and touch response. Furby encourages imaginative play, conversation, and screen-free entertainment for kids and nostalgic collectors alike.",
    "features": [
      "chats, laughs, and dances",
      "Voice activated",
      "Amazon Overall Pick"
    ],
    "highlight": "Affordable Super-fun intelligent toy",
    "rating": 4.8,
    "reviewCount": 772,
    "ratingSource": "Amazon",
    "ratingLastChecked": "2026-05-08",
    "ratingUrl": "Amazon.com: FURBY DJ Interactive Toy, Neon Star, Snuggly Electronic Plush, Music, Lights, Motion, & Games, Speaks English & Furbish, 32 in Long, 6+ Years (Amazon Exclusive) : Toys & Games",
    "price": "$50.11",
    "priceSource": "Amazon",
    "priceLastChecked": "2026-05-08",
    "priceCategory": "Budget Friendly",
    "productUrl": "",
    "imageUrl": "/images/products/interactive_pet_toys.png",
    "flags": {
      "gifts": true,
      "topPick": true,
      "camera": false,
      "internetAccess": false,
      "affiliateAgreement": false
    }
  },
  {
    "slug": "robot-pet-dog",
    "name": "Robot Pet Dog",
    "manufacturer": "Loona",
    "manufacturerAndProduct": "Loona Robot Pet Dog",
    "type": "AI & Robotic",
    "category": "Dog",
    "bestFor": [
      "Children",
      "Families"
    ],
    "blurb": "Loona Robot Pet Dog is an AI-powered robot pet with voice interaction, facial recognition, touch response, and smart home monitoring. Designed for kids and families, Loona delivers interactive companionship, learning, and entertainment.",
    "features": [
      "Recognizes faces",
      "Voice Command Enabled",
      "Auto Re-charge"
    ],
    "highlight": "",
    "rating": 4.2,
    "reviewCount": 1199,
    "ratingSource": "Amazon",
    "ratingLastChecked": "2026-05-08",
    "ratingUrl": "Amazon.com: Loona Robot Pet Dog ChatGPT-4o Smart AI-Powered Companion Voice & Gesture Control, Real-Time Interaction Robotics Toys for Kids, Home Monitoring - Includes Charging Dock : Toys & Games",
    "price": "$499.00",
    "priceSource": "Amazon",
    "priceLastChecked": "2026-05-08",
    "priceCategory": "Premium",
    "productUrl": "",
    "imageUrl": "/images/products/futuristic_ai_pets.png",
    "flags": {
      "gifts": true,
      "topPick": true,
      "camera": false,
      "internetAccess": false,
      "affiliateAgreement": false
    }
  }
];

export const faqs = [
  { q: "What is the difference between interactive pets and AI & robotic pets?", a: "Interactive pets usually focus on comfort, touch response, and simple engagement. AI & robotic pets generally add movement, sensors, or more advanced behavior." },
  { q: "Are smart pets good for seniors?", a: "Many buyers choose them for companionship and low maintenance. The best fit depends on comfort needs, ease of use, and how much technology the user wants." },
  { q: "Do these products need Wi-Fi?", a: "Some advanced models may use apps or connectivity, but many simpler interactive companion products do not." },
  { q: "Are these a good gift?", a: "Yes. Buyers often choose them for holidays, birthdays, or thoughtful gifts for parents and grandparents." }
];
