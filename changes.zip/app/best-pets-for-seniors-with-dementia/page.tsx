import { PageShell } from "@/components/layout";
import { BestForCard } from "@/components/best-for-card";
import { ViewDetailsLink } from "@/components/view-details-link";
import { ScoreGauge, ScoreBar } from "@/components/score-gauge";
import {
  IconSparkleClean, IconDurability, IconUsers, IconShieldCheck,
  IconBattery, IconPrivacy, IconBrain, IconHeartHands, IconChat, IconAward,
  featureIcon, StarRating,
} from "@/components/best-for-icons";
import { products } from "@/components/site-data";
import Link from "next/link";
import { CustomizeRankings } from "@/components/customize-rankings";

import {
  SPREADSHEET_UPDATED, TOP_SCORE_IN_GROUP, TOP_PICK_RAW_SCORE, TOP_PICK_PERCENT,
  RANKED_SLUGS, SCORE_PERCENT, RUNNER_NOTES, TOP_PICK_CRITERIA_DATA, JSON_LD,
} from "./page-data";
import { SCORES } from "./scores";

const ICON_MAP: Record<string, React.ComponentType<{ className?: string }>> = {
  "Caregiver Burden": IconUsers,
  "Dementia Suitability": IconBrain,
  "Emotional Comfort Potential": IconHeartHands,
  "Recognizable Pet Appearance": IconHeartHands,
  "Safety Risk": IconShieldCheck,
  "Sound Quality": IconChat,
};
const TOP_PICK_CRITERIA = TOP_PICK_CRITERIA_DATA.map((c) => ({
  ...c, Icon: ICON_MAP[c.label] ?? IconSparkleClean,
}));

const WHY_TOP_PICK_BULLETS = [
  { label: "Dementia Suitability", note: "Score of 5 — specifically evaluated for suitability in dementia and memory care contexts." },
  { label: "Safety Risk", note: "No choking hazards, sharp edges, or tip-over risk — appropriate for unsupervised use." },
  { label: "Recognizable Pet Appearance", note: "Score of 5 — immediately familiar animal form that residents respond to warmly." },
  { label: "Emotional Comfort Potential", note: "Score of 5 — consistent emotional engagement without overstimulation." },
];

export default function BestForPage() {
  const ranked = RANKED_SLUGS
    .map((slug) => products.find((p) => p.slug === slug))
    .filter(Boolean) as NonNullable<(typeof products)[number]>[];
  const topPick = ranked[0];
  const runners = ranked.slice(1);

  return (
    <PageShell>
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON_LD }} />

      <section className="relative overflow-hidden bg-cyan-100 py-8 sm:py-10">
        <div
          className="absolute inset-y-0 right-0 hidden w-1/3 sm:block"
          aria-hidden="true"
          style={{
            backgroundImage: [
              "linear-gradient(to right,",
              "  rgba(207,250,254,1) 0%,",
              "  rgba(207,250,254,0.7) 6%,",
              "  rgba(207,250,254,0.2) 13%,",
              "  rgba(207,250,254,0) 20%",
              "),",
              "url('/dementia-hero.png')",
            ].join(" "),
            backgroundSize: "auto, cover",
            backgroundPosition: "left, center 20%",
            backgroundRepeat: "no-repeat, no-repeat",
          }}
        />
        <div className="container-shell relative z-10">
          <p className="eyebrow">Best For Rankings</p>
          <h1 className="mt-1 text-4xl font-extrabold tracking-tight text-slate-900 sm:text-5xl">
            Best Pets for Seniors with Dementia
          </h1>
          <p className="mt-2 max-w-2xl text-base font-medium leading-7 text-slate-700">
            Safe, familiar companions ranked specifically for dementia care — calming, easy to recognise, and appropriate for memory care settings.
          </p>
          <p className="mt-2 inline-flex items-center gap-2 text-xs font-semibold text-trust-700">
            <span className="inline-flex h-6 w-6 items-center justify-center rounded-full bg-trust-500 text-white text-[10px]">✓</span>
            Ratings from Verified Sources · Updated {SPREADSHEET_UPDATED}
          </p>
        </div>
      </section>

      {topPick && (
        <section className="py-4 sm:py-5 bg-white">
          <div className="container-shell">
            <div className="overflow-hidden rounded-3xl border-2 border-cyan-200 shadow-soft">
              <div className="grid gap-0 lg:grid-cols-[1fr_1.2fr_0.9fr]">
                <div className="relative bg-cyan-100">
                  <div className="absolute top-0 left-5 z-10 w-14 sm:w-16">
                    <div className="bg-trust-500 text-white text-center font-bold pt-3 pb-5 shadow-soft"
                         style={{ clipPath: "polygon(0 0, 100% 0, 100% 100%, 50% 82%, 0 100%)" }}>
                      <span className="block text-sm leading-none">#1</span>
                      <span className="mt-1 block text-[8px] leading-tight tracking-wide">TOP<br />PICK</span>
                    </div>
                  </div>
                  {topPick.imageUrl ? (
                    <div className="h-full w-full" style={{ aspectRatio: "1/1" }}>
                      <img src={topPick.imageUrl} alt={topPick.name} className="block h-full w-full object-cover" />
                    </div>
                  ) : (
                    <div className="flex h-full min-h-[280px] items-center justify-center text-slate-400 text-sm p-4 text-center">
                      {topPick.manufacturer}<br />{topPick.name}
                    </div>
                  )}
                </div>
                <div className="flex flex-col justify-center gap-1.5 p-2.5 sm:p-3">
                  <p className="text-xs font-semibold uppercase tracking-wide text-brand-700">{topPick.manufacturer}</p>
                  <h2 className="text-4xl font-extrabold text-slate-900">{topPick.name}</h2>
                  {topPick.rating !== undefined && topPick.reviewCount !== undefined && (
                    <div className="flex flex-wrap items-baseline gap-1.5 text-sm">
                      <StarRating rating={topPick.rating} className="text-2xl" />
                      <span className="font-semibold text-slate-900">{topPick.rating.toFixed(1)}</span>
                      <span className="text-slate-700">({topPick.reviewCount.toLocaleString()} reviews)</span>
                    </div>
                  )}
                  <p className="text-sm leading-6 text-slate-700">{topPick.blurb}</p>
                  <div className="grid grid-cols-3 gap-1 pt-0.5">
                    {topPick.features.map((f) => (
                      <div key={f} className="flex flex-row items-center gap-1.5 rounded-xl bg-cyan-100 border border-cyan-200 px-2 py-1.5 text-xs font-medium text-brand-900">
                        {featureIcon(f, "h-8 w-8 shrink-0 text-cyan-700")}
                        <span>{f}</span>
                      </div>
                    ))}
                  </div>
                  <div className="flex items-center justify-between gap-1 pt-1">
                    <div>
                      <p className="text-xs font-semibold uppercase tracking-wide text-brand-700">Price</p>
                      <p className="text-xl font-bold text-slate-900">{topPick.price}</p>
                    </div>
                    <ViewDetailsLink
                      product={topPick}
                      className="inline-flex items-center justify-center rounded-full bg-trust-500 px-8 py-3 text-base font-semibold text-white transition hover:-translate-y-0.5 hover:bg-trust-600"
                    >
                      View at {topPick.manufacturer}
                    </ViewDetailsLink>
                  </div>
                </div>
                <div className="flex flex-col items-center gap-2 border-t-2 border-cyan-200 bg-white p-2.5 sm:p-3 lg:border-l-2 lg:border-t-0">
                  <ScoreGauge percent={TOP_PICK_PERCENT} rawScore={TOP_PICK_RAW_SCORE} accentColor="text-cyan-700" />
                  <p className="text-[11px] text-slate-400 text-center">* % relative to top scorer in this group</p>
                  <div className="w-full space-y-1">
                    {TOP_PICK_CRITERIA.map((c) => (
                      <ScoreBar key={c.label} label={c.label} weight={c.weight} score={c.score} barColor="bg-cyan-500" />
                    ))}
                  </div>
                </div>
              </div>
            </div>
            <Link href="/best-pets-for-seniors-with-dementia/scoring" className="mt-2 inline-flex items-center gap-1 text-sm font-semibold text-trust-600 underline underline-offset-4 hover:text-trust-800">
              Show detailed scoring results →
            </Link>
          </div>
        </section>
      )}

      {topPick && WHY_TOP_PICK_BULLETS.length > 0 && (
        <section className="py-4 sm:py-5 bg-cyan-100">
          <div className="container-shell">
            <h2 className="text-xl font-extrabold tracking-tight text-slate-900 sm:text-2xl">
              Why {topPick.name} is Our Top Pick
            </h2>
            <ul className="mt-3 grid gap-2 sm:grid-cols-2 lg:grid-cols-3">
              {WHY_TOP_PICK_BULLETS.map((b) => (
                <li key={b.label} className="flex items-start gap-2 rounded-2xl border border-cyan-200 bg-white p-3">
                  <span className="mt-0.5 flex h-5 w-5 shrink-0 items-center justify-center rounded-full bg-trust-500 text-white text-[10px] font-bold">✓</span>
                  <div>
                    <p className="text-sm font-semibold text-slate-900">{b.label}</p>
                    <p className="text-xs leading-5 text-slate-600">{b.note}</p>
                  </div>
                </li>
              ))}
            </ul>
          </div>
        </section>
      )}

      <section className="pb-4 sm:pb-5 bg-white">
        <div className="container-shell">
          <h2 className="text-xl font-extrabold tracking-tight text-slate-900 sm:text-2xl">Also Ranked — Top 5 Picks</h2>
          <p className="mt-0.5 text-sm text-slate-700">More strong choices, ranked by the same criteria.</p>
          <div className="mt-2 grid gap-2.5 sm:grid-cols-2 xl:grid-cols-4">
            {runners.map((product, i) => (
              <div key={product.slug} className="flex flex-col">
                <p className="mb-1 text-xs font-bold uppercase tracking-wide text-slate-500">#{i + 2} Ranked</p>
                <BestForCard product={product} note={RUNNER_NOTES[product.slug]} className="flex-1"
                             scorePercent={SCORE_PERCENT[product.slug]} accentColor="text-cyan-700" />
              </div>
            ))}
          </div>
          <div className="mt-4 border-t border-cyan-200 pt-3 text-center">
            <Link href="/best-pets-for-seniors-with-dementia/scoring" className="inline-flex items-center gap-1 text-sm font-semibold text-trust-600 underline underline-offset-4 hover:text-trust-800">
              Show detailed scoring results →
            </Link>
          </div>
        </div>
      </section>

      <CustomizeRankings scores={SCORES} topScore={TOP_SCORE_IN_GROUP} />

    </PageShell>
  );
}
