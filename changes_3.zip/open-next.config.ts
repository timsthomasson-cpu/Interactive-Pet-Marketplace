// OpenNext Cloudflare configuration.
//
// Without an incremental cache configured, every request to a prerendered
// page would re-render server-side from scratch, eating Worker CPU on each
// hit. With the KV cache wired up, the first request to each path renders
// once and stores the result in Workers KV; all subsequent requests serve
// from the cache with essentially zero Worker CPU.
//
// The KV namespace binding is named NEXT_CACHE_WORKERS_KV in wrangler.jsonc
// (this exact name is what kvIncrementalCache looks for).
//
// See https://opennext.js.org/cloudflare/caching for details.
import { defineCloudflareConfig } from "@opennextjs/cloudflare";
import kvIncrementalCache from "@opennextjs/cloudflare/kv-cache";

export default defineCloudflareConfig({
	incrementalCache: kvIncrementalCache
});
