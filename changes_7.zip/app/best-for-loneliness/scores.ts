// AUTO-GENERATED — do not edit by hand.
// Run: python Documentation/generate_ranked_list.py "Best for Loneliness"
// Generated: 2026-07-07

export const TOP_SCORE_IN_GROUP = 4.4;

export type BestForScoreRow = {
  slug: string; score: number; scorePercent: number; price: number;
  priceCategory: "Best Value" | "Budget Friendly" | "Premium"; animalCategory: "Cat" | "Dog" | "Panda" | "Robot"; type: "Ai & Robotic Pets" | "Fluffy Companion";
  movementLevel: number; soundQuality: number; visualContrast: number;
};

// Alias used by CustomizeRankings
// Legacy alias
export type MemoryCareScoreRow = BestForScoreRow;
export const SCORES: BestForScoreRow[] = [
  { slug: 'breathing-red-panda-plush', score: 3.20, scorePercent: 73, price: 119.00, priceCategory: 'Best Value', animalCategory: 'Panda', type: 'Fluffy Companion', movementLevel: 1, soundQuality: 4, visualContrast: 4 },
  { slug: 'matecat-1-1', score: 3.65, scorePercent: 83, price: 149.00, priceCategory: 'Best Value', animalCategory: 'Cat', type: 'Fluffy Companion', movementLevel: 2, soundQuality: 4, visualContrast: 3 },
  { slug: 'matecat-pro', score: 4.40, scorePercent: 100, price: 178.00, priceCategory: 'Best Value', animalCategory: 'Cat', type: 'Fluffy Companion', movementLevel: 3, soundQuality: 4, visualContrast: 3 },
  { slug: 'percy-1-1-robotic-companion-dog', score: 4.25, scorePercent: 97, price: 89.00, priceCategory: 'Budget Friendly', animalCategory: 'Dog', type: 'Fluffy Companion', movementLevel: 3, soundQuality: 4, visualContrast: 3 },
  { slug: 'percy-robot-cat', score: 4.10, scorePercent: 93, price: 89.00, priceCategory: 'Budget Friendly', animalCategory: 'Cat', type: 'Fluffy Companion', movementLevel: 3, soundQuality: 4, visualContrast: 3 },
  { slug: 'breathing-calico-percy-2-0', score: 4.15, scorePercent: 94, price: 109.00, priceCategory: 'Best Value', animalCategory: 'Cat', type: 'Fluffy Companion', movementLevel: 2, soundQuality: 4, visualContrast: 3 },
  { slug: 'ebo-air-2-familybot', score: 1.75, scorePercent: 40, price: 179.00, priceCategory: 'Best Value', animalCategory: 'Robot', type: 'Ai & Robotic Pets', movementLevel: 4, soundQuality: 3, visualContrast: 3 },
  { slug: 'ebo-air-2-plus-familybot', score: 1.75, scorePercent: 40, price: 359.00, priceCategory: 'Premium', animalCategory: 'Robot', type: 'Ai & Robotic Pets', movementLevel: 4, soundQuality: 3, visualContrast: 3 },
  { slug: 'ebo-air-2s-familybot', score: 1.75, scorePercent: 40, price: 279.00, priceCategory: 'Premium', animalCategory: 'Robot', type: 'Ai & Robotic Pets', movementLevel: 4, soundQuality: 3, visualContrast: 3 },
  { slug: 'ebo-x-familybot', score: 1.75, scorePercent: 40, price: 789.00, priceCategory: 'Premium', animalCategory: 'Robot', type: 'Ai & Robotic Pets', movementLevel: 4, soundQuality: 3, visualContrast: 3 },
  { slug: 'rola-mini-pet-monitor', score: 1.55, scorePercent: 35, price: 139.00, priceCategory: 'Best Value', animalCategory: 'Robot', type: 'Ai & Robotic Pets', movementLevel: 3, soundQuality: 3, visualContrast: 3 },
  { slug: 'companion-pet-cat-orange-tabby', score: 3.70, scorePercent: 84, price: 159.99, priceCategory: 'Best Value', animalCategory: 'Cat', type: 'Fluffy Companion', movementLevel: 2, soundQuality: 3, visualContrast: 4 },
  { slug: 'companion-pet-cat-silver', score: 3.70, scorePercent: 84, price: 159.99, priceCategory: 'Best Value', animalCategory: 'Cat', type: 'Fluffy Companion', movementLevel: 2, soundQuality: 3, visualContrast: 3 },
  { slug: 'companion-pet-cat-tuxedo', score: 3.70, scorePercent: 84, price: 159.99, priceCategory: 'Best Value', animalCategory: 'Cat', type: 'Fluffy Companion', movementLevel: 2, soundQuality: 3, visualContrast: 4 },
  { slug: 'companion-pet-pup-freckled', score: 3.70, scorePercent: 84, price: 179.00, priceCategory: 'Best Value', animalCategory: 'Dog', type: 'Fluffy Companion', movementLevel: 2, soundQuality: 3, visualContrast: 3 },
  { slug: 'companion-pet-pup-golden', score: 3.70, scorePercent: 84, price: 179.00, priceCategory: 'Best Value', animalCategory: 'Dog', type: 'Fluffy Companion', movementLevel: 2, soundQuality: 3, visualContrast: 4 },
  { slug: 'wuffy-robot-puppy', score: 2.60, scorePercent: 59, price: 25.99, priceCategory: 'Budget Friendly', animalCategory: 'Dog', type: 'Fluffy Companion', movementLevel: 3, soundQuality: 2, visualContrast: 3 },
  { slug: 'dj-furby', score: 3.10, scorePercent: 70, price: 50.11, priceCategory: 'Budget Friendly', animalCategory: 'Robot', type: 'Ai & Robotic Pets', movementLevel: 2, soundQuality: 3, visualContrast: 5 },
  { slug: 'robot-pet-dog', score: 3.10, scorePercent: 70, price: 499.00, priceCategory: 'Premium', animalCategory: 'Dog', type: 'Ai & Robotic Pets', movementLevel: 5, soundQuality: 3, visualContrast: 3 },
  { slug: 'grey-tabby-cat', score: 2.70, scorePercent: 61, price: 44.45, priceCategory: 'Budget Friendly', animalCategory: 'Cat', type: 'Fluffy Companion', movementLevel: 1, soundQuality: 2, visualContrast: 3 },
  { slug: 'original-border-collie', score: 2.70, scorePercent: 61, price: 44.45, priceCategory: 'Budget Friendly', animalCategory: 'Dog', type: 'Fluffy Companion', movementLevel: 1, soundQuality: 2, visualContrast: 3 },
  { slug: 'original-chocolate-lab', score: 2.70, scorePercent: 61, price: 44.45, priceCategory: 'Budget Friendly', animalCategory: 'Dog', type: 'Fluffy Companion', movementLevel: 1, soundQuality: 2, visualContrast: 3 },
  { slug: 'original-plush-white-cat', score: 2.70, scorePercent: 61, price: 53.90, priceCategory: 'Budget Friendly', animalCategory: 'Cat', type: 'Fluffy Companion', movementLevel: 1, soundQuality: 2, visualContrast: 4 },
  { slug: 'original-siamese-cat', score: 2.70, scorePercent: 61, price: 53.90, priceCategory: 'Budget Friendly', animalCategory: 'Cat', type: 'Fluffy Companion', movementLevel: 1, soundQuality: 2, visualContrast: 3 },
  { slug: 'kamomo', score: 3.50, scorePercent: 80, price: 349.00, priceCategory: 'Premium', animalCategory: 'Robot', type: 'Ai & Robotic Pets', movementLevel: 1, soundQuality: 3, visualContrast: 2 },
  { slug: '18011-smart-robot-dog', score: 2.15, scorePercent: 49, price: 69.99, priceCategory: 'Budget Friendly', animalCategory: 'Dog', type: 'Ai & Robotic Pets', movementLevel: 4, soundQuality: 2, visualContrast: 3 },
];
// Legacy alias for existing imports
export const MEMORY_CARE_SCORES = SCORES;
