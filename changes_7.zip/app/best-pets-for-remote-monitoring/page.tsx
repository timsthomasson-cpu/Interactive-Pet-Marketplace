import { PageShell } from "@/components/layout";
import { BestForCard } from "@/components/best-for-card";
import { ScoreGauge, ScoreBar } from "@/components/score-gauge";
import {
  IconSparkleClean, IconDurability, IconUsers, IconShieldCheck,
  IconBattery, IconPrivacy, IconBrain, IconHeartHands, IconChat, IconAward,
  featureIcon, StarRating,
} from "@/components/best-for-icons";
import { products } from "@/components/site-data";
import Link from "next/link";

// ── Auto-generated data ───────────────────────────────────────────────────────
import {
  SPREADSHEET_UPDATED, TOP_SCORE_IN_GROUP, TOP_PICK_RAW_SCORE, TOP_PICK_PERCENT,
  RANKED_SLUGS, SCORE_PERCENT, RUNNER_NOTES, TOP_PICK_CRITERIA_DATA, JSON_LD,
} from "./page-data";

// ── Icon mapping (update when criteria change) ────────────────────────────────
const ICON_MAP: Record<string, React.ComponentType<{ className?: string }>> = {
  "Ai / Advanced Interaction Level": IconChat,
  "Brand / Seller Reliability": IconAward,
  "Charging Convenience": IconBattery,
  "Customization Options": IconHeartHands,
  "Movement Level": IconHeartHands,
  "Privacy Risk": IconPrivacy,
  "Cleanability": IconSparkleClean,
};
const TOP_PICK_CRITERIA = TOP_PICK_CRITERIA_DATA.map((c) => ({
  ...c, Icon: ICON_MAP[c.label] ?? IconSparkleClean,
}));

// ── Review when top pick changes ──────────────────────────────────────────────
const WHY_TOP_PICK_BULLETS = [
  { label: "Ai / Advanced Interaction Level", note: "Top score for AI responsiveness — reacts naturally to voice and touch." },
  { label: "Charging Convenience", note: "Convenient charging that doesn't interrupt daily use." },
  { label: "Customization Options", note: "Highly customisable behaviour and interaction modes." },
  { label: "Brand / Seller Reliability", note: "Established brand with strong after-sale support." },
];

export default function BestForPage() {
  const ranked = RANKED_SLUGS
    .map((slug) => products.find((p) => p.slug === slug))
    .filter(Boolean) as NonNullable<(typeof products)[number]>[];
  const topPick = ranked[0];
  const runners = ranked.slice(1);

  return (
    <PageShell>
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON_LD }} />

      {/* ── Hero ── */}
      <section className="bg-sky-100 py-8 sm:py-10">
        <div className="container-shell">
          <div className="flex items-start gap-4">
            <div>
              <p className="eyebrow">Best For Rankings</p>
              <h1 className="mt-1 text-4xl font-extrabold tracking-tight text-slate-900 sm:text-5xl">
                Best Pets for Remote Monitoring
              </h1>
              <p className="mt-2 max-w-2xl text-base font-medium leading-7 text-slate-700">
                AI-connected companions with cameras and remote features, ranked for interaction quality, reliability, and family connectivity.
              </p>
              <p className="mt-2 inline-flex items-center gap-2 text-xs font-semibold text-trust-700">
                <span className="inline-flex h-6 w-6 items-center justify-center rounded-full bg-trust-500 text-white text-[10px]">✓</span>
                Ratings from Verified Sources · Updated {SPREADSHEET_UPDATED}
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* ── Top Pick ── */}
      {topPick && (
        <section className="py-4 sm:py-5 bg-white">
          <div className="container-shell">
            <div className="overflow-hidden rounded-3xl border-2 border-sky-200 shadow-soft">
              <div className="grid gap-0 lg:grid-cols-[1fr_1.2fr_0.9fr]">
                <div className="relative bg-sky-100">
                  <div className="absolute top-0 left-5 z-10 w-14 sm:w-16">
                    <div className="bg-trust-500 text-white text-center font-bold pt-3 pb-5 shadow-soft"
                         style={{ clipPath: "polygon(0 0, 100% 0, 100% 100%, 50% 82%, 0 100%)" }}>
                      <span className="block text-sm leading-none">#1</span>
                      <span className="mt-1 block text-[8px] leading-tight tracking-wide">TOP<br />PICK</span>
                    </div>
                  </div>
                  {topPick.imageUrl ? (
                    <div className="h-full w-full" style={{ aspectRatio: "1 / 1" }}>
                      <img src={topPick.imageUrl} alt={topPick.name} className="block h-full w-full object-cover" />
                    </div>
                  ) : (
                    <div className="flex h-full min-h-[280px] items-center justify-center text-slate-400 text-sm">
                      {topPick.manufacturer} — {topPick.name}
                    </div>
                  )}
                </div>
                <div className="flex flex-col justify-center gap-1.5 p-2.5 sm:p-3">
                  <p className="text-xs font-semibold uppercase tracking-wide text-brand-700">{topPick.manufacturer}</p>
                  <h2 className="text-4xl font-extrabold text-slate-900">{topPick.name}</h2>
                  {topPick.rating !== undefined && topPick.reviewCount !== undefined && (
                    <div className="flex flex-wrap items-baseline gap-1.5 text-sm">
                      <StarRating rating={topPick.rating} className="text-2xl" />
                      <span className="font-semibold text-slate-900">{topPick.rating.toFixed(1)}</span>
                      <span className="text-slate-700">({topPick.reviewCount.toLocaleString()} reviews)</span>
                    </div>
                  )}
                  <p className="text-sm leading-6 text-slate-700">{topPick.blurb}</p>
                  <div className="grid grid-cols-3 gap-1 pt-0.5">
                    {topPick.features.map((f) => (
                      <div key={f} className="flex flex-row items-center gap-1.5 rounded-xl bg-sky-100 border border-sky-200 px-2 py-1.5 text-xs font-medium text-brand-900">
                        {featureIcon(f, "h-8 w-8 shrink-0 text-sky-700")}
                        <span>{f}</span>
                      </div>
                    ))}
                  </div>
                  <div className="flex items-center justify-between gap-1 pt-1">
                    <div>
                      <p className="text-xs font-semibold uppercase tracking-wide text-brand-700">Price</p>
                      <p className="text-xl font-bold text-slate-900">{topPick.price}</p>
                    </div>
                    <a href={topPick.productUrl ?? "#"} target="_blank" rel="noopener noreferrer nofollow sponsored"
                       className="inline-flex items-center justify-center rounded-full bg-trust-500 px-8 py-3 text-base font-semibold text-white transition hover:-translate-y-0.5 hover:bg-trust-600">
                      View Details
                    </a>
                  </div>
                </div>
                <div className="flex flex-col items-center gap-2 border-t-2 border-sky-200 bg-white p-2.5 sm:p-3 lg:border-l-2 lg:border-t-0">
                  <ScoreGauge percent={TOP_PICK_PERCENT} rawScore={TOP_PICK_RAW_SCORE} accentColor="text-sky-700" />
                  <p className="mt-1 text-[11px] text-slate-400 text-center">* % relative to top scorer in this group</p>
                  <div className="w-full space-y-1">
                    {TOP_PICK_CRITERIA.map((c) => (
                      <ScoreBar key={c.label} label={c.label} weight={c.weight} score={c.score} barColor="bg-sky-500" />
                    ))}
                  </div>
                </div>
              </div>
            </div>
            <Link href="/best-pets-for-remote-monitoring/scoring" className="mt-2 inline-flex items-center gap-1 text-sm font-semibold text-trust-600 underline underline-offset-4 hover:text-trust-800">
              Show detailed scoring results →
            </Link>
          </div>
        </section>
      )}

      {/* ── Why Top Pick ── */}
      {topPick && WHY_TOP_PICK_BULLETS.length > 0 && (
        <section className="py-4 sm:py-5 bg-sky-100">
          <div className="container-shell">
            <h2 className="text-xl font-extrabold tracking-tight text-slate-900 sm:text-2xl">
              Why {topPick.name} is Our Top Pick
            </h2>
            <ul className="mt-3 grid gap-2 sm:grid-cols-2 lg:grid-cols-3">
              {WHY_TOP_PICK_BULLETS.map((b) => (
                <li key={b.label} className="flex items-start gap-2 rounded-2xl border border-sky-200 bg-white p-3">
                  <span className="mt-0.5 flex h-5 w-5 shrink-0 items-center justify-center rounded-full bg-trust-500 text-white text-[10px] font-bold">✓</span>
                  <div>
                    <p className="text-sm font-semibold text-slate-900">{b.label}</p>
                    <p className="text-xs leading-5 text-slate-600">{b.note}</p>
                  </div>
                </li>
              ))}
            </ul>
          </div>
        </section>
      )}

      {/* ── Also Ranked ── */}
      <section className="pb-4 sm:pb-5 bg-white">
        <div className="container-shell">
          <h2 className="text-xl font-extrabold tracking-tight text-slate-900 sm:text-2xl">
            Also Ranked — Top 5 Picks
          </h2>
          <p className="mt-0.5 text-sm text-slate-700">More strong choices, ranked by the same criteria.</p>
          <div className="mt-2 grid gap-2.5 sm:grid-cols-2 xl:grid-cols-4">
            {runners.map((product, i) => (
              <div key={product.slug} className="flex flex-col">
                <p className="mb-1 text-xs font-bold uppercase tracking-wide text-slate-500">
                  #{i + 2} Ranked
                </p>
                <BestForCard
                  product={product}
                  note={RUNNER_NOTES[product.slug]}
                  className="flex-1"
                  scorePercent={SCORE_PERCENT[product.slug]}
                  accentColor="text-sky-700"
                />
              </div>
            ))}
          </div>
          <div className="mt-4 border-t border-sky-200 pt-3 text-center">
            <Link href="/best-pets-for-remote-monitoring/scoring" className="inline-flex items-center gap-1 text-sm font-semibold text-trust-600 underline underline-offset-4 hover:text-trust-800">
              Show detailed scoring results →
            </Link>
          </div>
        </div>
      </section>
    </PageShell>
  );
}
