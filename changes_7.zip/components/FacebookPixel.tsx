'use client';

import Script from 'next/script';

/**
 * Facebook / Meta Pixel loader.
 *
 * Pixel ID: 27196529296663414
 * Fires a PageView event on every page load automatically.
 * Loaded afterInteractive so it does not block page render.
 *
 * To track newsletter signups as Lead events, call:
 *   window.fbq('track', 'Lead');
 * from the BeehiivEmbed component after a successful subscription.
 */
export default function FacebookPixel() {
  const pixelId = '27196529296663414';

  return (
    <>
      <Script id="facebook-pixel" strategy="afterInteractive">
        {`
          !function(f,b,e,v,n,t,s)
          {if(f.fbq)return;n=f.fbq=function(){n.callMethod?
          n.callMethod.apply(n,arguments):n.queue.push(arguments)};
          if(!f._fbq)f._fbq=n;n.push=n;n.loaded=!0;n.version='2.0';
          n.queue=[];t=b.createElement(e);t.async=!0;
          t.src=v;s=b.getElementsByTagName(e)[0];
          s.parentNode.insertBefore(t,s)}(window, document,'script',
          'https://connect.facebook.net/en_US/fbevents.js');
          fbq('init', '${pixelId}');
          fbq('track', 'PageView');
        `}
      </Script>
      <noscript>
        {/* eslint-disable-next-line @next/next/no-img-element */}
        <img
          height="1"
          width="1"
          style={{ display: 'none' }}
          src={`https://www.facebook.com/tr?id=${pixelId}&ev=PageView&noscript=1`}
          alt=""
        />
      </noscript>
    </>
  );
}
